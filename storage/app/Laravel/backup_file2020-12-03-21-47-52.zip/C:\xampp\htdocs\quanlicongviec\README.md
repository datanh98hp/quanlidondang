# quanlidondang
Quan li don hang - do an tot nghiep

- fb: https://www.facebook.com/datanh98.vimaru.cnt
- Zalo : 0869029018
- Instagram : https://www.instagram.com/dat_anh_IT/

# database : 
   link:  https://1drv.ms/u/s!AtjSDoRwpzkxleAl7l_SquTAo0VHhQ?e=UuEBwu
# Cài đặt local
    composer install
    npm install & npm run dev
    
# RUN
    php artisan serve 
