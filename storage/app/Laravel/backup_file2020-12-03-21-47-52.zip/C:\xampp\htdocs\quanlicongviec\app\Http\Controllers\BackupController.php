<?php

namespace App\Http\Controllers;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;

class BackupController extends Controller
{
    public function backup_view(){
        $listFileBackUp = glob(Storage::path('Laravel'));
        $arr_listFile = [];
        foreach ($listFileBackUp as $filename) {
            # code...
            array_push($arr_listFile,$filename);
        }
        dd($arr_listFile);
        return view('backup.backup');
    }
    public function backup_file(Schedule $schedule){

        $schedule->command('backup:run');
        // $schedule->exec('php artisan backup:run');

        return Storage::download(storage_path('Laravel/'.date('Y-m-d-H-i-s').'.zip'));
    }
}
