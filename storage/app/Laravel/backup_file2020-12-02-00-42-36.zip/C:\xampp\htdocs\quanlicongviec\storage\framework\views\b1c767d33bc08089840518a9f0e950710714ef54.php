 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="row justify-content-center">
        <div class="col-md-8"> 
            <form class="form-group" action="/update-vl/<?php echo e($kh->id); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                <div class="form-group">
                  <label for="recipient-name" class="col-form-label">Ho tên KH:</label>
                  <input type="text" class="form-control" id="recipient-name" name="Hoten" value="<?php echo e($kh->Hoten); ?>">
                </div>
                <div class="form-group">
                  <label for="message-text" class="col-form-label" >SDT:</label>
                  <input class="form-control" id="" value="<?php echo e($kh->SDT); ?> " name="SDT" >
                </div>
                <div class="form-group">
                    <label for="recipient-name" class="col-form-label">Email:</label>
                    <input type="email" class="form-control" id="recipient-name" name="Email" value="<?php echo e($kh->Email); ?>">
                </div>
                <div class="form-group">
                    
                        <label for="validationTooltip04">Loại KH</label>
                        <select class="custom-select" id="validationTooltip04" name="typeKH" value="<?php echo e($kh->typeKH); ?>" required>
                            <option value="Thường" <?php if($kh->typeKH==="Thường"): ?>
                                selected="true"
                            <?php else: ?>
                            
                            <?php endif; ?>>Thường</option>
                            <option value="Khách quen" <?php if($kh->typeKH==="Khách quen"): ?>
                              selected="true"
                          <?php else: ?>
                         
                          <?php endif; ?>>Khách quen</option>
                          <option value="VIP" <?php if($kh->typeKH==="VIP"): ?>
                            selected="true"
                        <?php else: ?>
                       
                        <?php endif; ?>>VIP</option>
                        </select>
                        <div class="invalid-tooltip">
                         Nhập đầy đủ thông tin
                        </div>
        
                </div>
                <div class="form-group">
                    <label for="recipient-name" class="col-form-label">Công ty:</label>
                    <input type="text" class="form-control" id="recipient-name" name="Cty" value="<?php echo e($kh->Cty); ?>">
                </div>
                <div class="form-group">
                    <button class="btn btn-success">Cập nhật</button>
                </div>
            </form>
        </div>
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/Danhmuc/khachhang/edit-danhmuc-kh.blade.php ENDPATH**/ ?>