 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <!-- $slot -->
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    
    <div class="row" style="margin:30px;justify-content: space-evenly">
        <a href="#" class="btn card border-primary mb-3" style="max-width: 100%;">
          
          <div class="card-body text-link mb-4 text-center">
            <h5 class="card-title">Tổng đơn hàng trong tháng</h5>
            <h3 class="card-text"><?php echo e($TongDonhang_thang); ?></h3>
            <h4 class="card-text">Đơn hàng</h4>
          </div>
        </a>
          <a href="#" class="btn card border-primary mb-4" style="max-width: 100%;">
            
            <div class="card-body text-primary text-center">
              <h5 class="card-title">Tổng đơn hàng trong ngày</h5>
              <h3 class="card-text"><?php echo e($countDonhang); ?></h3>
              <h4 class="card-text">Đơn hàng</h4>
            </div>
          </a>
          <a href="#" class="btn card border-success mb-4 text-center" style="max-width: 18rem;">
    
            <div class="card-body">
              <h5 class="card-title">Tổng đơn hàng hoàn thành trong ngày</h5>
              <h3 class="card-text"><?php echo e($countDh_Hoanthanh); ?></h3>
              <h4 class="card-text">Đơn hàng</h4>
            </div>
          </a>
          <a href="#" class="btn card border-success mb-4 text-center" style="max-width: 18rem;">
           
            <div class="card-body text-success">
              <h5 class="card-title">Tổng thu nhập Đơn hàng trong ngày</h5>
              <h3 class="card-text"><?php echo e(number_format($count_gt_Dh_ht)); ?></h3>
              <h4 class="card-text">VND</h4>
            </div>
          </a>
          <a href="#" class="btn card border-danger mb-4 text-center" style="max-width: 18rem;">
           
            <div class="card-body text-danger">
              <h5 class="card-title">Tổng thu/chi tiêu trong ngày</h5>
              <h3 class="card-text"><?php echo e(number_format($day_thu).' / '.number_format($day_chi)); ?></h3>
              <h4 class="card-text">VND</h4>
            </div>
          </a>
          
    </div>
    <div class="container-fluid">
        
        
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-chart-area mr-1"></i>
                 - Thu nhập bình quân trong tháng - <?php echo e(date('m')); ?>

            </div> 
            
            <div class="card-body">
              <canvas id="charDT" width="100%" height="30">
            </div>
            <div class="card-footer small text-muted"> Cập nhật : <?php echo e(now()); ?></div>
        </div>
        
    </div>
    
   
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<script>
    var month_thu = <?php echo ($month_thu); ?>;
    var month_chi = <?php echo ($month_chi); ?>;
    var ctx2 = document.getElementById('charDT');
    var myChart = new Chart(ctx2, {
        type: 'bar',
        data: {
            labels: ['Thu', 'Chi'],
            datasets: [{
                label: 'Chi',
                data: [month_thu,month_chi],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            },
           
        }
    });
</script>
// 
<?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/dashboard.blade.php ENDPATH**/ ?>