 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <h2 class="text-center">Thông tin đơn hàng</h2>
    <div class="form-group center">
      <a class="btn btn-link" style="margin:0% 48%" href="/print-donhang/<?php echo e($donhang->id); ?>"> <i class="fas fa-print"></i> In </a>
    </div>
    <div class="card  border-danger col-md-9" style="margin:0% 15%">
      <?php if(session('status')): ?>
      <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

      </div>
      <?php endif; ?>
        <div class="form-froup">
          <?php if($donhang->Trang_thai==='Hoàn thành'): ?>

            <form class="form" action="/undo-hoanthanh-donhang/<?php echo e($donhang->id); ?>" method="POST" style="margin: 2% 0% 0% 70%">
              <?php echo e(csrf_field()); ?>

              <?php echo e(method_field('PUT')); ?>

              <button type="submit" class="btn btn-light "><i class="fas fa-uncheck"></i> <span style="color: green"> Hủy chốt đơn </span></button>
            </form>
   
          <?php else: ?>
            
            <form class="form" action="/hoanthanh-donhang/<?php echo e($donhang->id); ?>" method="POST" style="margin: 2% 0% 0% 70%">
              <?php echo e(csrf_field()); ?>

              <?php echo e(method_field('PUT')); ?>

              <button type="submit" class="btn btn-light "><i class="fas fa-check"></i> <span style="color: green">Chốt đơn hàng</span></button>
            </form>
          <?php endif; ?>
        </div>
        
        <form action="/update-donhang/<?php echo e($donhang->id); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>

         
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Người lập đơn hàng:</label>
            <input type="text" class="form-control" id="recipient-name" name="" value="<?php echo e($username); ?>" disabled placeholder="Họ và tên">
          </div>

          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Tên Mặt hàng:</label>
     
            <table class="table table-borderless">
              <thead>
                <tr>
                  
                  <th scope="" style="width:300px">Mặt hàng</th>
                  <th scope="">Số lượng</th>
                  <th scope=""><a href="javascript:;" class="btn btn-success addRow">+</a></th>
                  <th scope=""></a></th>
               
                </tr>
              </thead>
              <tbody id="content" >
                <?php $__currentLoopData = $mathang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($item->id_Donhang === $donhang->id ): ?>
                  
                  <tr>
                    <td>
                      
                        <select id="inputState" class="form-control" name="id_Banggia[]">
                          <option selected>Chọn...</option>
                          <?php $__currentLoopData = $bg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($it->id); ?>" selected><?php echo e($it->TenLoai); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td>
                      <input type="number" min="0" pattern="[0-9]+([\.,][0-9]+)?" step="0.01" class="form-control" name="Soluong[]" value="<?php echo e($item->Soluong); ?>">
                    </td>
              
                    <td><a href="javascript:;" class="btn btn-dark deleteRow">-</a></td>
                    <td>
                        <a href="/del-one-mathang/<?php echo e($item->id); ?>"><i class="far fa-trash-alt"></i> Xóa mặt hàng</a>
                    </td>
                  </tr>
                  <?php endif; ?>
                       
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
              </tbody>

            </table>
          </div>

          <div class="form-group">
              <label for="message-text" class="col-form-label">Ngày trả</label>
          <input type="text"   class="form-control"  name="Tg_giao" value="<?php echo e($donhang->Tg_giao); ?>"> 
      
          </div>
        
          <div class="form-group">
            <label for="message-text" class="col-form-label">Cọc trước</label>
            <input type="text" class="form-control"  name="Coc_truoc" value="<?php echo e($donhang->Coc_truoc); ?>">
        </div>
          <div class="modal-footer">
            <button type="submit" <?php if($donhang->Trang_thai==="Hoàn thành"): ?>{ disabled } <?php endif; ?> class="btn btn-primary">Lưu</button>
          </div>

        </form>
      </div>
     

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<script>
    $('thead').on('click','.addRow',function(){
      var tr = '<tr>'+
                    '<td>'+
                      
                       '<select id="inputState" class="form-control" name="id_Banggia[]">'+
                          '<option selected>Chọn...</option>'+
                          '<?php $__currentLoopData = $bg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>'+
                            '<option value="<?php echo e($it->id); ?>"><?php echo e($it->TenLoai); ?></option>'+
                          '<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>'+
                        '</select>'+
                    '</td>'+
                    '<td>'+
                      '<input type="number" min="0" class="form-control" name="Soluong[]" value="">'+
                    '</td>'+
              
                    '<td><a href="javascript:;" class="btn btn-dark deleteRow">-</a></td>'+
                    '<td>'+
                        // '<a href="/del-one-mathang/">Xóa</a>'+
                    '</td>'+
                  '</tr>';
      $('#content').append(tr);
    });

    $('tbody').on('click','.deleteRow',function(){
      $(this).parent().parent().remove();
    });
  </script><?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/ketoan/EditBill.blade.php ENDPATH**/ ?>