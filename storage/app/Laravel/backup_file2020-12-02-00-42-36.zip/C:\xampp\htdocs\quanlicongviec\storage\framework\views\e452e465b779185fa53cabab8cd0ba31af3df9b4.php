<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
<div>
    <div class="card text-center" style="width: 100%;margin:0% ">
      <div class="card-body">
      
        <!-- When there is no desire, all things are at peace. - Laozi -->
      <div class="row " style="text-align: center;justify-content: center">
          <div class="" style="display: flex">
            <div class="justify-content-center" style="margin-left:0%;">
                

                <h2 class="text-center" style="font-family: 'Lexend Peta', sans-serif;color: red">TRUNG TÂM QUẢNG CÁO TRẺ</h2>
                <h1 class="text-center" style="font-family: 'Bungee Inline', cursive;color: red;">Thiện Phúc</h1>
                <span style="color: red">DC: Số 73 Trần Tất Văn - TT. An Lão - Hải Phòng * SDT: 0965 054 109 - 0867 10 03 89 </span>
              <h3 class="text-center" style=" color:black;padding:20px;font-weight: 600;text-transform: uppercase" >Bảng lương nhân viên từ <?php echo e($start); ?> đến  <?php echo e($end); ?> </h3>
              <h6 class="my-3" style="font-style: oblique">Thời gian : <span class="address_oder"><?php echo e(now()); ?></span></h6>
            </div>
          </div>
        </div>
    <h6 class="">THIẾT KẾ - HOÀN THIỆN BIỂN QUẢNG CÁO THEO YÊU CẦU - IN TRÊN MỌI CHẤT LIỆU - IN PHUN KHỔ LỚN - 
        IN OFFSET - CẮT CHỮ VI TÍNH - CẤT CHỮ MICA NỔI - LẮP ĐÈN NEON SIGN - IN THIỆP CƯỚI - GIẤY KHEN - GIẤY MỜI - IN ẢNH ...
    </h6>
    <hr color="">
    <div class="collunm mx-auto my-4">
        
        
        <table class="table" id="table-bill" style="width:100%;padding:10% 0% 0% 0%">
            <thead class="table display thead-dark table-striped">
              <tr>
                <th scope="col">#</th>
                <th scope="col">Họ tên nhân viên</th>
                <th scope="col">SDT</th>
                <th scope="col">Số ngày làm</th>
                <th scope="col">Hệ số lương</th>
                <th scope="col">Lương thực lĩnh</th>
              </tr>
            </thead>
            <tbody>

              <?php $__currentLoopData = $nhanvien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr>
                        <td scope="row">
                          <?php echo e($item->id); ?>

                        </td>
                        <td><?php echo e($item->Hoten); ?></td>
                        <td><?php echo e($item->sdt); ?></td>
                        <td>
                            <?php echo e(floor( abs(strtotime($item->start_work) - strtotime($item->end_work ) ) /(60*60*24) )); ?>

                        </td>   
                        <td>
                            <?php echo e($item->Hesoluong); ?>

                        </td>
                        <td>
                            <?php echo e(number_format($item->Tienluong)); ?>

                        </td>
                      </tr> 
                      
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
       
    </div>
      </div>
      
    </div>
    <h5 class=" mx-4 text-left my-4">Người lập đơn</h5>
    <div class="mx-5 center">
      <p><?php echo e(Auth::user()->name); ?></p>
    </div>
  </div>
  <script>
    $(document).ready(function(){
      {
      // var txt;
      // if(confirm('Bạn có muốn In trang này')){
        window.print();
      // }else{
        
      // }
    }
    });
  </script>
  <?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/Nhanvien/print-ds-bangluong.blade.php ENDPATH**/ ?>