 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <?php $__env->startSection('title','Edit User'); ?>
    <div class="card border-light mb-3 center" style="max-width: 50rem;">
        <div class="card-header">Cập nhật thông tin người dùng</div>
        <div class="card-body">
        <form action="/user/update/<?php echo e($users->id); ?>" method="POST">
              <?php echo e(csrf_field()); ?>

              <?php echo e(method_field('PUT')); ?>

            <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="inputCity">Email</label>
                  <input type="text" disabled name="email" value="<?php echo e($users->email); ?>" class="form-control" id="inputCity">
                </div>
                <div class="form-group col-md-4">
                  <label for="inputState">Position
                </label>
                <select id="inputState" class="form-control" name="type" value="<?php echo e($users->type); ?>" name="type">
                    <option selected>Chọn...</option>
                    <option value="1">Admin</option>
                    <option value="2">Ke toan</option>
                    <option value="3">Designer</option>
                  </select>
                </div>
                
            </div>
            <button type="submit" class="btn btn-primary">Lưu</button>
            </form>
        </div>
      </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/Manager/edit.blade.php ENDPATH**/ ?>