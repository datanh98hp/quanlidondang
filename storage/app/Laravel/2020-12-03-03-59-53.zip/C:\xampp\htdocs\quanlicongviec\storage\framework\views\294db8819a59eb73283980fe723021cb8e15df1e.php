 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="col-md-10" style="margin: 0% 0% 10% 10%">
    <h2 class="text-center">Cập nhật thông tin -  <?php echo e($thiepcuoi->KH); ?></h2>
        
    <form action="/inthiepcuoi/update/<?php echo e($thiepcuoi->id); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

          <?php echo e(method_field('PUT')); ?>

            <div class="col-md-12">
                <div class="card">
                  <div class="card-body">
                      <div class="col-md-12">  
                          <div class="form-group">
                              <label for="inputAddress2">Khách hàng : </label>
                              <input type="text" class="form-control" name="KH" value="<?php echo e($thiepcuoi->KH); ?>" placeholder="Khách Hàng">
                          </div>
                      </div>
                      <hr>
                    <div class="form-row">
                      <div class="col-md-6">
                          <label>Nhà Trai</label>
                          <div class="form-group">
                              <label class="small mb-1" for="inputFirstName">Ông :</label>
                              <input class="form-control py-4" name="o_nhatrai" type="text" value="<?php echo e($thiepcuoi->o_nhatrai); ?>" placeholder="Ông" />
                              <label class="small mb-1" for="inputFirstName">Bà :</label>
                              <input class="form-control py-4" name="b_nhatrai" type="text" value="<?php echo e($thiepcuoi->b_nhatrai); ?>" placeholder="Bà" />
                          </div>
                      </div>
                      <div class="col-md-6">
                          <label>Nhà Gái</label>
                          <div class="form-group">
                              <label class="small mb-1" for="inputLastName">Ông :</label>
                              <input class="form-control py-4" name="o_nhatgai" type="text" value="<?php echo e($thiepcuoi->o_nhatgai); ?>" placeholder="Ông" />
                              <label class="small mb-1" for="inputLastName">Bà :</label>
                              <input class="form-control py-4" name="b_nhagai" type="text" value="<?php echo e($thiepcuoi->b_nhagai); ?>" placeholder="Bà" />
                          </div>
                      </div>
                       <h3 style="color: red;" class="text-center">Trân trọng 
                           <select required name="qh" name="qh"> 
                                <option value="kính" <?php if($thiepcuoi->qh==="kính"): ?>
                                    selected="true"
                                <?php else: ?>
                                
                                <?php endif; ?>>kính</option>
                                <option value="thân" <?php if($thiepcuoi->qh==="thân"): ?>
                                  selected="true"
                              <?php else: ?>
                             
                              <?php endif; ?>>thân</option>
                                
                              </select>
                           mời tới dự bữa cơm thân mật mừng lễ thành hôn của 
                           <select required name="of">
                                <option value="2" <?php if($thiepcuoi->of==="2"): ?>
                                    selected="true"
                                <?php else: ?>
                                
                                <?php endif; ?>>2</option>
                                <option value="2 con" <?php if($thiepcuoi->of==="2 con"): ?>
                                  selected="true"
                              <?php else: ?>
                            
                              <?php endif; ?>>2 con</option>
                              <option value="2 cháu" <?php if($thiepcuoi->of==="2 cháu"): ?>
                                  selected="true"
                              <?php else: ?>
                            
                              <?php endif; ?>>2 cháu</option>
                          </select>
                          chúng tôi.
                       </h3>
                  </div>
                  
                  <div class="form-row">
                      <div class="col-md-6">
                          <div class="form-group">
                              <label class="small mb-1" for="inputPassword">Chú rể :</label>
                              <input class="form-control py-4" name="chure" value="<?php echo e($thiepcuoi->chure); ?>" type="text" placeholder="" />
                          </div>
                          <div class="form-group">
                              <label for="exampleFormControlSelect1">Bậc</label>
                              <select class="form-control" required name="bac_chure">
                                <option value="Trưởng" <?php if($thiepcuoi->bac_chure==="Trưởng"): ?>
                                    selected="true"
                                <?php else: ?>
                                
                                <?php endif; ?>>Trưởng</option>
                                <option value="Thứ" <?php if($thiepcuoi->bac_chure==="Thứ"): ?>
                                  selected="true"
                              <?php else: ?>
                             
                              <?php endif; ?>>Thứ</option>
                                <option value="Út" <?php if($thiepcuoi->bac_chure==="Út"): ?>
                                  selected="true"
                              <?php else: ?>
                              
                              <?php endif; ?>>Út</option>
                              </select>
                          </div>
                      </div>
                      <div class="col-md-6">
                          <div class="form-group">
                              <label class="small mb-1" for="inputConfirmPassword">Cô dâu :</label>
                              <input class="form-control py-4" name="codau" value="<?php echo e($thiepcuoi->codau); ?>" type="text" placeholder="" />
                          </div>
                          <div class="form-group">
                              <label for="exampleFormControlSelect1">Bậc</label>
                              <select class="form-control" required name="bac_codau">
                                <option value="Trưởng" <?php if($thiepcuoi->bac_codau==="Trưởng"): ?>
                                    selected="true"
                                <?php else: ?>
                                
                                <?php endif; ?>>Trưởng</option>
                                <option value="Thứ" <?php if($thiepcuoi->bac_codau==="Thứ"): ?>
                                  selected="true"
                              <?php else: ?>
                             
                              <?php endif; ?>>Thứ</option>
                                <option value="Út" <?php if($thiepcuoi->bac_codau==="Út"): ?>
                                  selected="true"
                              <?php else: ?>
                              
                              <?php endif; ?>>Út</option>
                              </select>
                          </div>
                      </div>
                      <div class="col-md-6">  
                              <div class="input-group">
                                <div class="input-group-prepend">
                                  <div class="input-group-text">Giờ ăn cơm (nhà trai):</div>
                                </div>
                                <input type="time" class="form-control" name="time_an_trai" value="<?php echo e($thiepcuoi->time_an_trai); ?>" placeholder="Username">
                                <div class="input-group-prepend">
                                  <div class="input-group-text">Giờ tổ chức (nhà trai):</div>
                                </div>
                                <input type="time" class="form-control" name="time_tochuc_trai" value="<?php echo e($thiepcuoi->time_tochuc_trai); ?>" laceholder="Username">
                              </div>
                      </div>
                      <div class="col-md-6">  
                          <div class="input-group">
                            <div class="input-group-prepend">
                              <div class="input-group-text">Giờ ăn cơm (nhà gái):</div>
                            </div>
                            <input type="time" class="form-control" name="time_an_gai" value="<?php echo e($thiepcuoi->time_an_gai); ?>">
                            <div class="input-group-prepend">
                              <div class="input-group-text">Giờ tổ chức (nhà gái):</div>
                            </div>
                            <input type="time" class="form-control" name="time_tochuc_gai" value="<?php echo e($thiepcuoi->time_tochuc_gai); ?>">
                          </div>
                      </div>
                      <div class="col-md-6">  
                          <div class="form-group">
                              <label for="inputAddress2">Địa chỉ (nhà trai)</label>
                              <input type="text" class="form-control" name="diachi_nhatrai" value="<?php echo e($thiepcuoi->diachi_nhatrai); ?>" placeholder="Địa chỉ nhà trai">
                              <div class="col-md-6">
                                  <label for="inputEmail4">SĐT (trai) : </label>
                                  <input type="tel" class="form-control" name="sdt_trai" value="<?php echo e($thiepcuoi->sdt_trai); ?>">
                                  <label for="inputAddress2">Số lượng (nhà trai) :</label>
                                  <input type="number" min="0" name="soluong_gai" class="form-control" placeholder="Số lượng" value="<?php echo e($thiepcuoi->soluong_trai); ?>">
                              </div>
                          </div>
                      </div>
                      <div class="col-md-6">  
                          <div class="form-group">
                              <label for="inputAddress2">Địa chỉ (nhà gái)</label>
                              <input type="text" class="form-control" name="diachi_nhagai" value="<?php echo e($thiepcuoi->diachi_nhagai); ?>" placeholder="Địa chỉ nhà gái">
                              <div class="col-md-6">
                                  <label for="inputEmail4">SĐT (gái) : </label>
                                  <input type="tel" class="form-control" name="sdt_gai" value="<?php echo e($thiepcuoi->sdt_gai); ?>">
                                  <label for="inputAddress2">Số lượng (nhà trai) :</label>
                                  <input type="number" min="0" class="form-control" name="soluong_trai" placeholder="số lượng" value="<?php echo e($thiepcuoi->soluong_gai); ?>">
                              </div>
                          </div>
                      </div>
                      <hr>
                      <div class="input-group">
                          <div class="input-group-prepend">
                            <div class="input-group-text">Tổng số tiền :</div>
                          </div>
                          <input type="text" class="form-control" name="Tong_tien" placeholder="Tổng tiền" value="<?php echo e($thiepcuoi->Tong_tien); ?>">
                      </div>
                      <div class="input-group">
                          <div class="input-group-prepend">
                            <div class="input-group-text">Đặt trước :</div>
                          </div>
                          <input type="text" class="form-control" name="Dat_coc" placeholder="Đặt trước" value="<?php echo e($thiepcuoi->Dat_coc); ?>">
                      </div>
                      <div class="input-group">
                          <div class="input-group-prepend">
                            <div class="input-group-text">Code thiệp :  </div>
                          </div>
                          <input type="text" class="form-control" name="code_thiep" placeholder="Mã thiếp" value="<?php echo e($thiepcuoi->code_thiep); ?>">
                      </div>
                      <div class="input-group">
                          <div class="input-group-prepend">
                            <div class="input-group-text">Ngày trả :</div>
                          </div>
                          <input type="datetime" class="form-control" name="ngay_tra" placeholder="Ngày trả" value="<?php echo e($thiepcuoi->ngay_tra); ?>">
                      </div>
                      
                  </div>
                  
                  </div>
                </div>
                <div class="form-group mt-8 mb-8 col-sm-2 text-center ">
                    <button class="btn btn-primary btn-block" type="submit">Lưu</button>
                </div>
              </div>
        </form>
    </div>
    

     <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/Thiepcuoi/Edit.blade.php ENDPATH**/ ?>