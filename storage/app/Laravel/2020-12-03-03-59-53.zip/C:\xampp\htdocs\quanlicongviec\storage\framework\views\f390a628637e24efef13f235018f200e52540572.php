 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <style>
    .selected{
        background-color: slategrey;
        cursor: pointer;
    }
    th:hover {
      background-color: darkgrey;

    }
    .center {
                display: block;
                margin-left: 25%;
                margin-right: auto;
                width: 50%;
            }
          
</style>
    
  
  <div style="margin:10px 40px 10px;" >
    <button class="btn btn-primary" type="button" data-toggle="modal" data-target="#exampleModal" aria-expanded="false" aria-controls="collapseExample">
       + Thêm mới
    </button>
  </div>
  
  <?php if(session('status')): ?>
  <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
  <?php endif; ?>
    
    
    

  <div class="modal fade bd-example-modal-lg" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <form action="/inthiepcuoi/create" method="POST">
          <?php echo csrf_field(); ?>
          <div class="row">
            
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                    <div class="col-md-6">  
                        <div class="form-group">
                            <label for="inputAddress2">Khách hàng : </label>
                            <input type="text" class="form-control" name="KH" placeholder="Khách Hàng">
                            
                        </div>
                    </div>
                    <hr>
                  <div class="form-row">
                    <div class="col-md-6">
                        <label>Nhà Trai</label>
                        <div class="form-group">
                            <label class="small mb-1" for="inputFirstName">Ông :</label>
                            <input class="form-control py-4" name="o_nhatrai" type="text" placeholder="Ông " />
                            <label class="small mb-1" for="inputFirstName">Bà :</label>
                            <input class="form-control py-4" name="b_nhatrai" type="text" placeholder="Bà" />
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label>Nhà Gái</label>
                        <div class="form-group">
                            <label class="small mb-1" for="inputLastName">Ông :</label>
                            <input class="form-control py-4" name="o_nhatgai" type="text" placeholder="Ông" />
                            <label class="small mb-1" for="inputLastName">Bà :</label>
                            <input class="form-control py-4" name="b_nhagai" type="text" placeholder="Bà" />
                        </div>
                    </div>
                     <h3 style="color: red;" class="text-center">Trân trọng 
                         <select name="qh">   
                             <option value="thân">thân</option>
                             <option value="kính">kính</option>
                         </select>
                         mời tới dự bữa cơm thân mật mừng lễ thành hôn của 
                         <select name="of">   
                            <option value="2"> 2</option>
                            <option value="2 con">2 con</option>
                            <option value="2 cháu">2 cháu</option>
                        </select>
                        chúng tôi.
                     </h3>
                    
                    
                </div>
                
                <div class="form-row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="small mb-1" for="inputPassword">Chú rể :</label>
                            <input class="form-control py-4" name="chure" type="text" placeholder="CHú rể" />
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlSelect1">Bậc</label>
                            <select class="form-control" name="bac_chure">
                              <option value="Trưởng">Trưởng</option>
                              <option value="Thứ">Thứ</option>
                              <option value="Út">Út</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="small mb-1" for="inputConfirmPassword">Cô dâu :</label>
                            <input class="form-control py-4" name="codau" type="text" placeholder="" />
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlSelect1">Bậc</label>
                            <select class="form-control" name="bac_codau">
                              <option value="Trưởng">Trưởng</option>
                              <option value="Thứ">Thứ</option>
                              <option value="Út">Út</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">  
                            <div class="input-group">
                              <div class="input-group-prepend">
                                <div class="input-group-text">Giờ ăn cơm (nhà trai):</div>
                              </div>
                              <input type="time" class="form-control" name="time_an_trai" placeholder="Username">
                              <div class="input-group-prepend">
                                <div class="input-group-text">Giờ tổ chức (nhà trai):</div>
                              </div>
                              <input type="time" class="form-control" name="time_tochuc_trai" placeholder="Username">
                            </div>
                    </div>
                    <div class="col-md-6">  
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <div class="input-group-text">Giờ ăn cơm (nhà gái):</div>
                          </div>
                          <input type="time" class="form-control" name="time_an_gai" placeholder="Username">
                          <div class="input-group-prepend">
                            <div class="input-group-text">Giờ tổ chức (nhà gái):</div>
                          </div>
                          <input type="time" class="form-control" name="time_tochuc_gai" placeholder="Username">
                        </div>
                    </div>
                    <div class="col-md-6">  
                        <div class="form-group">
                            <label for="inputAddress2">Địa chỉ (nhà trai)</label>
                            <input type="text" class="form-control" name="diachi_nhatrai" placeholder="Địa chỉ nhà trai">
                            <div class="col-md-6">
                                <label for="inputEmail4">SĐT (trai) : </label>
                                <input type="tel" class="form-control" name="sdt_trai">
                                <label for="inputAddress2">Số lượng (nhà trai) :</label>
                                <input type="number" min="0" class="form-control" name="soluong_trai" placeholder="Số lượng">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">  
                        <div class="form-group">
                            <label for="inputAddress2">Địa chỉ (nhà gái)</label>
                            <input type="text" class="form-control" name="diachi_nhagai" placeholder="Địa chỉ nhà gái">
                            <div class="col-md-6">
                                <label for="inputEmail4">SĐT (gái) : </label>
                                <input type="tel" class="form-control" name="sdt_gai">
                                <label for="inputAddress2">Số lượng (nhà gái) :</label>
                                <input type="number" min="0" name="soluong_gai" class="form-control" placeholder="số lượng">
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="input-group">
                        <div class="input-group-prepend">
                          <div class="input-group-text">Tổng số tiền :</div>
                        </div>
                        <input type="text" class="form-control" name="Tong_tien" placeholder="Tổng">
                    </div>
                    <div class="input-group">
                        <div class="input-group-prepend">
                          <div class="input-group-text">Đặt trước :</div>
                        </div>
                        <input type="text" class="form-control" name="Dat_coc" placeholder="Đặt trước">
                    </div>
                    <div class="input-group">
                        <div class="input-group-prepend">
                          <div class="input-group-text">Loại :  </div>
                        </div>
                        <input type="text" class="form-control" name="code_thiep" placeholder="Mã thiếp">
                    </div>
                    <div class="input-group">
                        <div class="input-group-prepend">
                          <div class="input-group-text">Ngày trả :</div>
                        </div>
                        <input type="date" class="form-control" name="ngay_tra" placeholder="Ngày trả">
                    </div>
                    
                </div>
                
                </div>
              </div>
    
            </div>

          </div>
          <div class="form-group mt-8 mb-8 col-sm-2 text-center ">
              <button class="btn btn-primary btn-block" type="submit">Lưu</button>
          </div>
          
          </form>
      </div>
    </div>
  </div>
    
    
    <div class="col-sm-12">
      
      <div class="card text-center">
        
        <div class="card-body">
          <h3 class="card-title" style="color:red">Danh sách đơn đặt Thiệp cưới</h3>
          
          <table class="table thead-dark table-responesive display" id="dataTable">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">KH</th>
                <th scope="col">Cô dâu</th>
                <th scope="col">Chú rể</th>
                <th scope="col">SL-nhà trai</th>
                <th scope="col">SL-nhà gái</th>
                <th scope="col">Ngày trả</th>
                <th scope="col">Đặt cọc trước</th>
                <th scope="col">Thành tiền</th>
                <th scope="col">Còn lại</th>
                <th scope="col"></th>
                <th scope="col"></th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $thiepcuoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
              <th scope="row"><?php echo e($item->id); ?></th>
                <td><?php echo e($item->KH); ?></td>
                <td><?php echo e($item->codau); ?></td>
                <td><?php echo e($item->chure); ?></td>
                <td><?php echo e($item->soluong_trai); ?></td>
                <td><?php echo e($item->soluong_gai); ?></td>
                <td><?php echo e($item->ngay_tra); ?></td>
                <td><?php echo e(number_format($item->Dat_coc)); ?> VND</td>
                <td><?php echo e(number_format($item->Tong_tien)); ?> VND</td>
                <td><?php echo e(number_format($item->Tong_tien - $item->Dat_coc)); ?> VND</td>
                <td>
                
                    <a class="btn btn-info" href="/inthiepcuoi/chitiet/<?php echo e($item->id); ?>"><i class="far fa-file"></i></a>
                    <a class="btn btn-warning" href="/inthiepcuoi/edit/<?php echo e($item->id); ?>"><i class="far fa-edit"></i></a>
                    
                </td>
                <td>
                  <form action="/inthiepcuoi/delete/<?php echo e($item->id); ?>" method="POST">
                    <?php echo e(@csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <button class="btn btn-danger" type="submit"><i class="fas fa-trash-alt"></i></button>
                  </form>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    
    <script>
      $(document).ready(function() {
      var table = $('#dataTable').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Vietnamese.json"
        }
      });
   
  $('#dataTable tbody').on('click', 'tr', function () {
      var data = table.row( this ).data();
      // alert( 'You clicked on '+data ); 
      // $('.data_display').text(data);

      $('.name_display').text(''+data[0]);
      $('.pos_display').text(''+data[1]);
      $('.phone_display').text(''+data[3]);
      ///
      if ( $(this).hasClass('selected') ) {
          $(this).removeClass('selected');
      }
      else {
          table.$('tr.selected').removeClass('selected');
          $(this).addClass('selected');
      }
  } );
} );

  </script>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/Thiepcuoi/Thiepcuoi.blade.php ENDPATH**/ ?>