{{-- <x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        {{ __('Nhân viên') }}
    </h2>
</x-slot> --}}
<div>
    {{$title}}
    <!-- The whole future lies in uncertainty: live immediately. - Seneca -->
    
</div>