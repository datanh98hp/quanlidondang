 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <div>
<!-- Modal -->
<div class="modal fade " id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog modal-lg">
    <div class="modal-content">
    <form action="/create-thuchi" method="POST">
        <?php echo csrf_field(); ?>
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Thêm</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <table class="table table-borderless">
          <thead>
            <tr>
              
              <th scope="" style="width:300px">Tên CV</th>
              <th scope="">$ Thu</th>
              <th scope="">$ Chi</th>
              
              <th scope=""><a href="javascript:;" class="btn btn-success addRow">+</a></th>
            </tr>
          </thead>
          <tbody id="content">
            <tr>
              <td>
                <textarea type="text" rows="1" class="form-control" id="TenMH" name="NDCV[]"></textarea>
              </td>
              <td>
                <input type="number" min="0" class="form-control" id="Soluong" name="SoTen_Thu[]">
              </td>
              <td>
                <input type="number" min="0" class="form-control" id="Don_gia" name="SoTen_Chi[]">
              </td>
              <th scope="col"><a href="javascript:;" class="btn btn-danger deleteRow">-</a></th>
            </tr>
          </tbody>
        </table>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
        <button type="submit" class="btn btn-primary">Lưu</button>
      </div>
    </form>
    </div>
  </div>
</div>
<div class=" ml-5">
  <button type="button" class="btn btn-primary mx-auto" data-toggle="modal" data-target="#staticBackdrop">
    Thêm
  </button>
 
</div>

  </div>
  
  <div class="justify-content-sm-end">
    
    <?php if(session('status')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('statusBC')); ?>

    </div>
  <?php endif; ?>
    <div class="center" id="formTgBC">
      <form action="/create/bc-thuchi" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-row align-items-baseline mx-auto">
          <div class="col-sm-5 my-1">
            
            <div class="input-group">
              <div class="input-group-prepend">
                <div class="input-group-text">Từ ngày</div>
              </div>
              <input type="date" class="form-control" name="startdate" id="" placeholder="Username">
            </div>
          </div>
          <div class="col-sm-5 my-auto">
          
            <div class="input-group">
              <div class="input-group-prepend">
                <div class="input-group-text">Đến ngày</div>
              </div>
              <input type="date" class="form-control" id="" name="enddate" placeholder="Username">
            </div>
          </div>
          <div class="col-auto mx-auto">
            <button type="submit" class="btn btn-success">Xuất báo cáo</button>
          </div>
        </div>
      </form>
    </div>
  </div>
    <h2 class="text-center" style="color: blue">Bảng thu chi</h2>
      <h6  class="text-center">( <?php echo e(date("F j, Y")); ?> )</h6>
        <!-- Button trigger modal -->
    
    <div class="row">
        <div class="col-sm-8 mx-auto">
          <?php if(session('status')): ?>
          <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
          <?php endif; ?>
          <table class="table table-striped table-hover thead-dark" >
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Công việc</th>
                <th scope="col">Thu</th>
                <th scope="col">Chi</th>
                <th scope="col">Còn lại</th>
                <th scope="col">Người thanh toán</th>
                <th scope="col"></th>
                <th scope="col"></th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $thuchi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->NDCV); ?></td>
                <td><?php echo e($item->SoTen_Thu); ?></td>
                <td><?php echo e($item->SoTen_Chi); ?></td>
                <td><?php echo e($item->SoTen_Thu - $item->SoTen_Chi); ?></td>
                <td>
                  <?php if($item->id_user===Auth::user()->id): ?>
                  <?php echo e(Auth::user()->name); ?>

                  <?php endif; ?>
                </td>
                <td>
                  
                </td>
                <td>
                  <form action="/del-thuchi/<?php echo e($item->id); ?>" method="POST">
                    <?php echo e(@csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <button class="btn btn-danger" type="submit"><i class="fas fa-trash-alt"></i></button>
                  </form>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
          </table>
          <h3 class="text-right" style="margin-right: 20px;font-weight: 1000">Còn lại : <span style="font-weight: 800"><?php echo e(number_format($Conlai)); ?> VND</span></h3>
          <h3 class="text-right" style="margin-right: 20px;font-weight: 1000">Tổng thu : <span style="font-weight: 800"><?php echo e(number_format($Tongthu)); ?> VND</span></h3>
          <h3 class="text-right" style="margin-right: 20px;font-weight: 1000">Tổng chi: <span style="font-weight: 800"><?php echo e(number_format($Tongchi)); ?> VND</span></h3>
        </div>
        
    </div>
   
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<script>
  $('thead').on('click','.addRow',function(){
    var tr =  '<tr>'+
                    '<td>'+
                      '<textarea type="text" rows="1" class="form-control" id="TenMH" name="NDCV[]"></textarea>'+
                    '</td>'+
                    '<td>'+
                      '<input type="number" min="0" class="form-control" id="Soluong" name="SoTen_Thu[]">'+
                    '</td>'+
                    '<td>'+
                      '<input type="text" class="form-control" id="Don_gia" name="SoTen_Chi[]">'+
                    '</td>'+
                    '<th scope="col"><a href="javascript:;" class="btn btn-danger deleteRow">-</a></th>'+
                  '</tr>';
    $('#content').append(tr);
  });
  $('tbody').on('click','.deleteRow',function(){
    $(this).parent().parent().remove();
  });
</script>
<?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/Thuchi/Bangthuchi.blade.php ENDPATH**/ ?>