<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Nhan vien</title>
</head>
<body>
    <p><?php echo e($user); ?></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/Nhanvien.blade.php ENDPATH**/ ?>