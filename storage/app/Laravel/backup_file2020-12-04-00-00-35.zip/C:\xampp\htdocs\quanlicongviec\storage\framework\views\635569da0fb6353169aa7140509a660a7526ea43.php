 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <div class="row mx-auto">   
    <div class="col-sm-12">
      <h2 class="title" style="color:blue; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif">Danh sách vật liệu tồn kho</h2>
      <table class="table" id="dataTable_VL" style="max-width: 100%">
        <thead class="thead-dark">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Tên VL</th>
            <th scope="col">SL</th>
            <th scope="col">Đơn vị</th>
            <th scope="col">NCC</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $ds_Vatlieu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($item->id); ?></th>
              <td><?php echo e($item->TenVL); ?></td>
              <td><?php echo e($item->Soluong_ton); ?></td>
              <td><?php echo e($item->Donvi_tinh); ?></td>
              <td>
                <?php $__currentLoopData = $ncc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($nc->id === $item->id_ncc): ?>
                        <?php echo e($nc->TenNCC); ?>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </td>
            </tr>  
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
      </table>
    </div>
  </div>
  <hr>
  <div class="card-group" style="margin:0% 0% 30px 0%">
    <div class="card">
      <img src="..." class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Danh sách phiếu nhập</h5>
        <table class="table table-hover" id="dataTable" style="padding: 1%">
          <thead>
            <tr>
              <th scope="col" style="width:50px">#</th>
              <th scope="col" style="width:100px">Người nhập</th>
              <th scope="col" style="width:200px">T.gian nhập</th>
              <th scope="col" style="width:200px" >Mô tả</th>
              <th scope="col" style="width:100px" ></th>
            </tr>
          </thead>
          <tbody>

            <?php $__currentLoopData = $phieunhap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
              <th scope="row"><?php echo e($item->id); ?></th>
              <td>
                <?php if($item->id_user===Auth::user()->id): ?>
                <?php echo e(Auth::user()->name); ?>

                <?php endif; ?>
                
              </td>
              <td><?php echo e($item->Tgian_nhap); ?></td>
              <td><?php echo e(substr($item->Description,0,20)); ?>... </td>
              <td>
                <a class="btn btn-info" href="/chitiet-phieunhap-vatlieu/<?php echo e($item->id); ?>">Chi tiết</a>
              </td>
            </tr>  

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          </tbody>
        </table>
        
      </div>
    </div>
    <div class="card">
      <img src="..." class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Danh sách phiếu xuất</h5>
        <table class="table table-hover table-dark" id="dataTable2" style="padding: 1%">
          <thead>
            <tr>
              <th scope="col" style="width:50px">#</th>
              <th scope="col" style="width:100px">Người nhập</th>
              <th scope="col" style="width:200px" >T.gian xuất</th>
              <th scope="col" style="width:100px">Đơn hàng</th>
              <th scope="col" style="width:200px">Mô tả</th>
              <th scope="col" style="width:100px"></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $phieuxuat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($item->id); ?></th>
              <td>
                <?php if($item->id_user===Auth::user()->id): ?>
                <?php echo e(Auth::user()->name); ?>

                <?php endif; ?>
                
              </td>
              <td><?php echo e($item->Tgian_xuat); ?></td>
              <td><?php echo e($item->id_Donhang); ?></td>
              <td><?php echo e(substr($item->Description,0,20)); ?>... </td>
              <td>
                <a class="btn btn-info" href="/chitiet-phieuxuat-vatlieu/<?php echo e($item->id); ?>">Chi tiết</a>
              </td>
            </tr>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        
      </div>
    </div>
  </div>

      <hr>
      
     <?php if(session('status')): ?>
      <div class="alert alert-danger">
          <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>
      <div class="row" style="padding: 10px">
        <div class="col-sm-6">
          <div class="card border-primary mb-4" style="max-width: 100%;margin:10pt">
            <div class="card-header text-center">Phiếu nhập</div>
            <div class="card-body text-primary">
              <h5 class="card-title">Phiếu nhập vật liệu</h5>
              
              <form action="/phieunhap-vatlieu" method="POST">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                  <label for="">Người nhập phiếu :</label>
                  <input type="text" class="form-control" id="id_user" name="id_user" disabled value="<?php echo e($username); ?>" placeholder="">
                </div>
                <div class="form-group">
                  

                  
                  <table class="table table-borderless center" >
                    <thead id="thead_Nhap">
                      <tr>
                        
                        <th scope="" style="width:200px">Tên vật liệu</th>
                        <th scope="" style="width:100px">Số lượng</th>
                        <th class="show_when_create" scope="" style="width:120px">Đơn giá</th>
                        <th class="show_when_create" scope="" style="width:150px">Nơi cấp</th>
                        <th class="show_when_create" scope="" style="width:130px">Đơn vị</th>
                        <th scope=""><a href="javascript:;" class="btn btn-success addRow">+</a></th>
    
                      </tr>
                    </thead>
                    <tbody id="content_Nhap">
                      <tr>
                        <td id="NhapVL"> 
                          
                          
                        </td>
                        <td>
                          <input type="number" min="0" class="form-control" id="Soluong_ton" name="Soluong_ton[]">
                        </td>
                        <td  class="show_when_create">
                          <input type="text" class="form-control" id="Don_gia" name="Don_gia[]">
                        </td>
                        <td class="show_when_create">
                          
                          <select class="custom-select" name="id_ncc[]">
                            <option selected value="">...Chọn...</option>
                            <?php $__currentLoopData = $ncc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($item->id); ?>"><?php echo e($item->TenNCC); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </td> 
                        <td class="show_when_create">
                          
                          <select class="custom-select" name="Donvi_tinh[]">
                            <option selected>Chọn...</option>
                            <option value="Cái">Cái</option>
                            <option value="Cuộn">Cuộn</option>
                            <option value="M">M</option>
                          </select>
                        </td>
                        
                        <td scope="col"><a href="javascript:;" class="btn btn-danger deleteRow">-</a></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
    
                <div class="form-group">
                  <label for="">Mô tả : </label>
                  <textarea class="form-control" name="Description" rows="7" cols="6"></textarea>
                </div>
                
                <div class="footer">
                  
                  <button type="submit" class="btn btn-primary">Lưu</button>
                </div>
              </form>
              
            </div>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="card border-success mb-4" style="max-width: 100%;margin:10pt">
            <div class="card-header text-center">Phiếu xuất</div>
            <div class="card-body text-primary ">
              <h5 class="card-title ">Phiếu Xuất vật liệu</h5>
              
              <form action="/phieuxuat-vatlieu" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <label for="exampleFormControlInput1">Người nhập phiếu :</label>
                  <input type="text" class="form-control" name="" value="<?php echo e($username); ?>" disabled placeholder="">
                  
                </div>
                <div class="input-group mb-2">
                  <div class="input-group-prepend">
                    <label class="input-group-text" for="inputGroupSelect01">Chọn đơn hàng</label>
                  </div>
                  <select id="TenDH" class="custom-select" name="TenDH" required>
                    <option selected>Chọn...</option>
                    <?php $__currentLoopData = $ds_Donhang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($item->id); ?>"><?php echo e($item->TenDH); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php $__errorArgs = ['TenDH'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                  <label for="recipient-name" class="col-form-label">Danh sách vật liệu xuất:</label>
           
                  <table class="table table-borderless center" style="padding: 10px">
                    <thead id="thead_Xuat">
                      <tr>
                        
                        <th scope="" style="width:200px">Tên vật liệu</th>
                        <th scope="" style="width:100px">Số lượng</th>
                        
                        <th scope=""><a href="javascript:;" class="btn btn-success addRow">+</a></th>
    
                      </tr>
                    </thead>
                    <tbody id="content_Xuat">
                      <tr>
                        <td>
                          
                          <select id="TenVL" class="custom-select <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="TenVL[]" required>
                            <option selected>Chọn...</option>
                            <?php $__currentLoopData = $ds_Vatlieu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($item->TenVL); ?>"><?php echo e($item->TenVL); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </td>
                        <td>
                          <input type="number" min="0" class="form-control" id="Soluong_xuat"  name="Soluong_xuat[]">
                        </td>
                        
                        <td scope="col"><a href="javascript:;" class="btn btn-danger deleteRow">-</a></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
    
                <div class="form-group">
                  <label for="exampleFormControlTextarea1">Mô tả : </label>
                  <textarea class="form-control" id="exampleFormControlTextarea1" name="Description" rows="5" cols="6"></textarea>
                </div>
            
                <div class="footer">
                  
                  <button type="submit" class="btn btn-primary">Lưu</button>
                </div>
              </form>
              
            </div>
          </div>
        </div>
      </div>
      <script>
        $('#thead_Nhap').on('click','.addRow',function(){
          var tr =  '<tr>'+
                          '<td >'+
                            '<select id="TenVL" class="custom-select <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="TenVL[]" required>'+
                            '<option selected>Chọn...</option>'+
                            '<?php $__currentLoopData = $ds_Vatlieu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>'+
                              '<option value="<?php echo e($item->id); ?>"><?php echo e($item->TenVL); ?></option>'+
                            '<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>'+
                          '</select>'+
                          '</td>'+
                          '<td>'+
                            '<input type="number" min="0" class="form-control" id="Soluong" name="Soluong[]">'+
                          '</td>'+
                          // '<td class="show_when_create">'+
                          //   '<input type="text" class="form-control" id="Don_gia" name="Don_gia[]">'+
                          // '</td>'+
                          // '<td class="show_when_create">'+
                          // '<input type="text" class="form-control" id="Noi_cap" name="NSX[]">'+
                          // '</td>'+
                          // '<td class="show_when_create">'+
                          //   '<select class="custom-select" name="Donvi[]">'+
                          //     '<option value="" selected>...Chọn...</option>'+
                          //     '<option value="Cái">Cái</option>'+
                          //     '<option value="Chiếc">Chiếc</option>'+
                          //     '<option value="M">M</option>'+
                          //   '</select>'+
                          // '</td>'+
                          '<th scope="col"><a href="javascript:;" class="btn btn-danger deleteRow">-</a></th>'+
                        '</tr>';
          $('#content_Nhap').append(tr);
        });
        $('tbody').on('click','.deleteRow',function(){
          $(this).parent().parent().remove();
        });
      </script>
       <script>
        $('#thead_Xuat').on('click','.addRow',function(){
          var tr =  '<tr>'+
                          '<td>'+
                            '<select id="TenVL" class="custom-select <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="TenVL[]" required>'+
                            '<option selected>Chọn...</option>'+
                            '<?php $__currentLoopData = $ds_Vatlieu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>'+
                              '<option value="<?php echo e($item->id); ?>"><?php echo e($item->TenVL); ?></option>'+
                            '<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>'+
                          '</select>'+
                          // '</td>'+
                          '<td>'+
                            '<input type="number" min="0" class="form-control" id="Soluong" name="Soluong_xuat[]">'+
                          '</td>'+
                          
                          '<th scope="col"><a href="javascript:;" class="btn btn-danger deleteRow">-</a></th>'+
                        '</tr>';
          $('#content_Xuat').append(tr);

        });
        $('tbody').on('click','.deleteRow',function(){
          $(this).parent().parent().remove();
        });
      </script>
      <script>
         $(document).ready( function () {
            $('#dataTable').DataTable({
              "language": {
            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Vietnamese.json",
          
          
        }
            });
        } );
        $(document).ready( function () {
            $('#dataTable2').DataTable({
              "language": {
            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Vietnamese.json",
          
        }
            });
        } );
        $(document).ready( function () {
            $('#dataTable_VL').DataTable({
              "language": {
            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Vietnamese.json",
          
        }
            });
        } );
      </script>
      <script>
       
      //  $('#TenVL_input').hide();
       $('#NhapVL').append('<select id="TenVL_select" class="custom-select <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="TenVL[]">'+
                            '<option selected value="">Chọn...</option>'+
                            '<?php $__currentLoopData = $ds_Vatlieu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>'+
                          '<option value="<?php echo e($item->TenVL); ?>"><?php echo e($item->TenVL); ?></option>'+
                            '<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>'+
                          '</select>');
        var timeClick = 1;
        $('.show_when_create').hide();

        $('#check_input').click(function(){
         
          timeClick++;
          if(timeClick % 2===0){
            
            $('#TenVL_select').remove();
            $('#TenVL_input').remove();
            $('.show_when_create').show();
            $('#NhapVL').append('<input type="text" class="form-control" id="TenVL_input" name="TenVL[]">').show();
            }else if(timeClick % 2!==0){
            
            $('#TenVL_input').remove();
            $('#TenVL_select').remove();
            $('.show_when_create').hide();
            $('#NhapVL').append('<select id="TenVL_select" class="custom-select <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="TenVL[]">'+
                            '<option selected value="">Chọn...</option>'+
                            '<?php $__currentLoopData = $ds_Vatlieu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>'+
                          '<option value="<?php echo e($item->TenVL); ?>"><?php echo e($item->TenVL); ?></option>'+
                            '<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>'+
                          '</select>');
           
          }
          console.log(timeClick);
        });
      
      </script>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/Vatlieu/vatlieu.blade.php ENDPATH**/ ?>