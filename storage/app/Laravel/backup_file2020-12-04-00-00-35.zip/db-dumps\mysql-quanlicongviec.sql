
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `_nhanvien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_nhanvien` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Hoten` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sdt` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_work` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `end_work` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Hesoluong` double(4,2) NOT NULL,
  `Position` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `luong_h` int(11) NOT NULL,
  `Tienluong` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `_nhanvien` WRITE;
/*!40000 ALTER TABLE `_nhanvien` DISABLE KEYS */;
INSERT INTO `_nhanvien` VALUES (2,'Bui Thao','0364694528','17-10-2020','24-10-2020',1.50,'ketoan',20000,850000,'2020-10-19 18:01:08',NULL),(3,'DA','0869625145','2020-10-04T01:22','2020-10-20T01:22',1.50,'designer',20000,3150000,'2020-10-19 11:22:48','2020-10-19 11:22:48'),(5,'Do VAn DAt','0869029018','2020-10-04T13:00','2020-10-20T17:00',1.00,'thi_cong',20000,3060000,'2020-10-20 10:33:43','2020-10-20 10:33:43');
/*!40000 ALTER TABLE `_nhanvien` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `banggia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banggia` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `TenLoai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Dongia` int(255) DEFAULT 0,
  `Donvi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `banggia` WRITE;
/*!40000 ALTER TABLE `banggia` DISABLE KEYS */;
INSERT INTO `banggia` VALUES (3,'Biển bạt loại thường',80000,'Mét vuông','2020-11-28 04:50:23','2020-11-28 04:50:23'),(5,'Biển Bạt loại tốt',120000,'Mét vuông','2020-11-29 03:01:15','2020-11-29 03:01:15');
/*!40000 ALTER TABLE `banggia` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `donhang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `donhang` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `TenDH` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_user` bigint(20) unsigned NOT NULL,
  `id_Khachhang` bigint(20) unsigned NOT NULL,
  `Tg_giao` datetime NOT NULL,
  `Trang_thai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Tong_gia` int(11) NOT NULL,
  `Coc_truoc` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `donhang_id_user_foreign` (`id_user`),
  KEY `donhang_id_khachhang_foreign` (`id_Khachhang`),
  CONSTRAINT `donhang_id_khachhang_foreign` FOREIGN KEY (`id_Khachhang`) REFERENCES `khachhang` (`id`),
  CONSTRAINT `donhang_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `donhang` WRITE;
/*!40000 ALTER TABLE `donhang` DISABLE KEYS */;
INSERT INTO `donhang` VALUES (33,'sads',12,5,'2020-11-29 22:44:00','Hoàn thành',360000,0,'2020-11-29 15:44:13','2020-12-02 19:10:57'),(35,'test2',12,1,'2020-11-29 23:43:00','Đang xử lí',320000,0,'2020-11-29 16:43:25','2020-12-02 18:56:11');
/*!40000 ALTER TABLE `donhang` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `event_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_start_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_start_time` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_end_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_end_time` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (2,'2020-11-13 19:11:52','2020-11-13 19:11:52','Trả đơn hàng cho anh Mạnh Decal','2020-11-14','12:00 AM','2020-11-14','11:59 PM','Trừ nợ 2 cuộn decal đỏ - 150.000 VND');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `khachhang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `khachhang` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Hoten` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SDT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `typeKH` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Thường',
  `Cty` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `khachhang` WRITE;
/*!40000 ALTER TABLE `khachhang` DISABLE KEYS */;
INSERT INTO `khachhang` VALUES (1,'Dat Anh','0869029018','datanh98hp@gmail.com','VIP','Dat Anh Marketing','0000-00-00 00:00:00',NULL),(5,'A Bình','0324554854','example@email.com','Thường','AD','2020-11-29 07:57:24','2020-11-29 07:57:24'),(6,'C Nga','0936123012',NULL,'Thường',NULL,'2020-11-29 09:01:40','2020-11-29 09:01:40'),(9,'Mới','161466555656',NULL,'Thường',NULL,'2020-11-29 09:57:32','2020-11-29 09:57:32');
/*!40000 ALTER TABLE `khachhang` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mathang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mathang` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_Donhang` bigint(20) unsigned NOT NULL,
  `id_Banggia` bigint(20) unsigned NOT NULL,
  `Soluong` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Desc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mathang_id_donhang_foreign` (`id_Donhang`),
  KEY `mathang_id_banggia_foreign` (`id_Banggia`),
  CONSTRAINT `mathang_id_banggia_foreign` FOREIGN KEY (`id_Banggia`) REFERENCES `banggia` (`id`),
  CONSTRAINT `mathang_id_donhang_foreign` FOREIGN KEY (`id_Donhang`) REFERENCES `donhang` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mathang` WRITE;
/*!40000 ALTER TABLE `mathang` DISABLE KEYS */;
INSERT INTO `mathang` VALUES (79,33,5,'1',NULL,'2020-12-02 18:54:55','2020-12-02 18:54:55'),(80,33,5,'2',NULL,'2020-12-02 18:54:55','2020-12-02 18:54:55'),(86,35,5,'2',NULL,'2020-12-02 18:56:11','2020-12-02 18:56:11'),(87,35,3,'1',NULL,'2020-12-02 18:56:11','2020-12-02 18:56:11');
/*!40000 ALTER TABLE `mathang` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2014_10_12_200000_add_two_factor_columns_to_users_table',1),(4,'2019_08_19_000000_create_failed_jobs_table',1),(5,'2019_12_14_000001_create_personal_access_tokens_table',1),(6,'2020_09_23_101558_create_sessions_table',1),(7,'2020_10_08_171449_create_events_table',2),(8,'2020_10_09_093512_create_task_table',3),(9,'2018_08_10_034632_create_events_table',4),(10,'2020_10_17_080756_create__nhanvien_table',5),(11,'2020_10_17_091007_create__nhanvien_table',6),(13,'2020_10_20_172102_create_thiepcuoi_table',7),(14,'2020_10_20_182844_create_events_table',8),(15,'2020_10_20_190516_create_events_table',9),(16,'2020_10_20_190845_create_events_table',10),(17,'2020_10_20_192440_create_events_table',11),(18,'2020_10_20_193436_create_events_table',12),(19,'2020_10_30_235225_create_mathang_table',13),(20,'2020_10_30_235426_create_donhang_table',14),(21,'2020_10_31_000600_create_mathang_table',15),(22,'2020_10_31_001200_create_mathang_table',16),(23,'2020_10_31_001548_create_phieunhap_table',17),(24,'2020_10_31_002109_create_phieuxuat_table',18),(25,'2020_10_31_002518_create_vatlieu_table',19),(26,'2020_11_07_180120_create_thuchi_table',20),(27,'2020_11_27_165605_create_khachhangs_table',21),(28,'2020_11_27_170616_create_banggias_table',21),(29,'2020_11_27_179999_create_banggias_table',22),(30,'2020_11_27_180000_create_mathang_table',23),(31,'2020_11_27_180001_create_khachhangs_table',24),(32,'2020_11_27_172624_create_nhacungcaps_table',25),(33,'2020_11_27_172625_create_vatlieu_table',26),(34,'2020_11_27_180002_create_khachhangs_table',27),(35,'2020_11_27_180003_create_khachhangs_table',28),(36,'2020_11_27_213919_create_khachhang_table',29),(37,'2020_11_27_213943_create_donhang_table',29),(38,'2020_11_27_214427_create_khachhang_table',30),(39,'2020_11_27_214907_create_donhang_table',31),(40,'2020_11_29_005124_create_mathang_table',32),(41,'2018_09_12_99999_create_backupverify_table',33);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `nhacungcaps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nhacungcaps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `TenNCC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DiaChi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Hotline` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Daidien` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `nhacungcaps` WRITE;
/*!40000 ALTER TABLE `nhacungcaps` DISABLE KEYS */;
INSERT INTO `nhacungcaps` VALUES (2,'Xưởng Sắt thép Quang Minh','230 Trần Tất Văn - An Lão - HP','0986457889','Minh Quang','2020-11-28 09:30:19','2020-11-28 09:30:19'),(3,'In Tuấn Đạt','246 Trường Chinh - Kiến An','0964566554','A Bình','2020-11-28 15:21:02','2020-11-29 03:08:09');
/*!40000 ALTER TABLE `nhacungcaps` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('dat198hp@gmail.com','$2y$10$TiI8LWOfB5ykG5c.Rfmi8.8xpOFH.EOB31W7wRrG6TMXU6vYecHJe','2020-11-22 17:22:09'),('datanh98hp@gmail.com','$2y$10$dvzSp1PGxQIS7HobvLuMkeg4eXgiUmUFuCKFly9l3UeY/a8e4yp/a','2020-11-22 17:22:38');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `phieunhap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phieunhap` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` bigint(20) unsigned NOT NULL,
  `Tgian_nhap` datetime NOT NULL DEFAULT current_timestamp(),
  `Description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `phieunhap_id_user_foreign` (`id_user`),
  CONSTRAINT `phieunhap_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `phieunhap` WRITE;
/*!40000 ALTER TABLE `phieunhap` DISABLE KEYS */;
INSERT INTO `phieunhap` VALUES (87,12,'2020-11-28 17:01:16','thêm','2020-11-28 10:01:16','2020-11-28 10:01:16'),(88,12,'2020-11-28 17:01:26',NULL,'2020-11-28 10:01:26','2020-11-28 10:01:26'),(89,12,'2020-11-28 17:01:33','q','2020-11-28 10:01:33','2020-11-28 10:01:33'),(90,12,'2020-11-28 17:04:00','11','2020-11-28 10:04:00','2020-11-28 10:04:00'),(91,12,'2020-11-28 17:09:24','tt','2020-11-28 10:09:24','2020-11-28 10:09:24'),(92,12,'2020-11-28 17:26:58',NULL,'2020-11-28 10:26:58','2020-11-28 10:26:58'),(93,12,'2020-11-28 17:31:51','vl4','2020-11-28 10:31:51','2020-11-28 10:31:51');
/*!40000 ALTER TABLE `phieunhap` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `phieuxuat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phieuxuat` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` bigint(20) unsigned NOT NULL,
  `Tgian_xuat` datetime NOT NULL DEFAULT current_timestamp(),
  `Description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_Donhang` bigint(20) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `phieuxuat_id_user_foreign` (`id_user`),
  KEY `phieuxuat_id_donhang_foreign` (`id_Donhang`),
  CONSTRAINT `phieuxuat_id_donhang_foreign` FOREIGN KEY (`id_Donhang`) REFERENCES `donhang` (`id`),
  CONSTRAINT `phieuxuat_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `phieuxuat` WRITE;
/*!40000 ALTER TABLE `phieuxuat` DISABLE KEYS */;
/*!40000 ALTER TABLE `phieuxuat` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('VdMfqbA1uNYzkXpTsLOQzVW27zgECDrATOgzszo1',12,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.67 Safari/537.36 Edg/87.0.664.52','YTo2OntzOjY6Il90b2tlbiI7czo0MDoiWGRsNmJSdkVqRTZTS3JNNUhkRUZGb0dMUXNEUkNIOGo1VHBYNG9WWCI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTI7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjA6IiQyeSQxMCRVVGZMTmQ0T0VZV1M1a3RDdVV4cjB1Y05JVWRLL2hSSXlmMERCTmdYNzhabXVsd2FGNUNQTyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9iYWNrdXBzLWZpbGUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjIxOiJwYXNzd29yZF9oYXNoX3NhbmN0dW0iO3M6NjA6IiQyeSQxMCRVVGZMTmQ0T0VZV1M1a3RDdVV4cjB1Y05JVWRLL2hSSXlmMERCTmdYNzhabXVsd2FGNUNQTyI7fQ==',1607014805);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `thiepcuoi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thiepcuoi` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` bigint(20) unsigned NOT NULL,
  `KH` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `o_nhatrai` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `b_nhatrai` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `o_nhatgai` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `b_nhagai` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qh` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `of` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chure` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codau` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bac_chure` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bac_codau` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_an_trai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_tochuc_trai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_an_gai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_tochuc_gai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `diachi_nhatrai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `diachi_nhagai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sdt_trai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sdt_gai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `soluong_trai` bigint(20) NOT NULL,
  `soluong_gai` bigint(20) NOT NULL,
  `Tong_tien` bigint(20) NOT NULL,
  `Dat_coc` bigint(20) NOT NULL,
  `code_thiep` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ngay_tra` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `thiepcuoi_id_user_foreign` (`id_user`),
  CONSTRAINT `thiepcuoi_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `thiepcuoi` WRITE;
/*!40000 ALTER TABLE `thiepcuoi` DISABLE KEYS */;
INSERT INTO `thiepcuoi` VALUES (2,12,'saffsdg','fsadasdgsdf','gjfghfhshs',NULL,'sdfhjsfhsdfh','thân','2 con','dfhfhdfgfadg','sdfhfdgdagfsjsdhf','Thứ','Út','09:00','13:30','09:00','14:00','jgoj svksdfofm nôsfksjvodov','údifjjojfdojgjosg','0150466346','015112126',200,150,1050000,500000,'XJA8fa','2020-03-01','2020-10-23 00:13:28','2020-11-21 12:55:59');
/*!40000 ALTER TABLE `thiepcuoi` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `thuchi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thuchi` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `NDCV` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SoTen_Thu` int(11) DEFAULT NULL,
  `SoTen_Chi` int(11) DEFAULT NULL,
  `id_user` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `thuchi_id_user_foreign` (`id_user`),
  CONSTRAINT `thuchi_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `thuchi` WRITE;
/*!40000 ALTER TABLE `thuchi` DISABLE KEYS */;
INSERT INTO `thuchi` VALUES (26,'Nhận tiền hang biển QC - DT Dat Anh',1200000,NULL,12,'2020-11-28 17:24:46','2020-11-28 17:24:46'),(27,'Nhập vỏ thiệp cưới 120 cái - BJ21L',NULL,320000,12,'2020-11-28 17:24:46','2020-11-28 17:24:46'),(28,'Mua vật liệu :\r\n+ x2 alumech tráng đá\r\n+ 5 nẹp nhôm Vàng\r\n+4 Nẹp nhôm trắng\r\n+ 5 cây sắt',NULL,1500000,12,'2020-12-02 19:18:12','2020-12-02 19:18:12'),(29,'Thu tiền hàng \r\n+ 2 biển QC Đạt Anh',2500000,NULL,12,'2020-12-02 19:18:12','2020-12-02 19:18:12');
/*!40000 ALTER TABLE `thuchi` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) unsigned DEFAULT NULL,
  `profile_photo_path` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (12,'dat admin','dat198hp@gmail.com',1,NULL,'$2y$10$UTfLNd4OEYWS5ktCuUxr0ucNIUdK/hRIyf0DBNgX78ZmulwaF5CPO',NULL,NULL,'hzhm3hMVkcThW8PGYF4Xs8AHHJ5N2x4q0iLMCYjjth9YOSzgjbCtf3E1nDx2',NULL,NULL,'2020-09-27 12:09:21','2020-11-24 14:18:36'),(13,'DESIGNER1','dat67653@st.vimaru.edu.vn',3,NULL,'$2y$10$xGZ/GFuAmWG5HyVHItQ.WeLEnoKYA1lZWNM58KtWPlbnUmKTy/5P2',NULL,NULL,NULL,NULL,NULL,'2020-09-29 20:49:41','2020-09-29 20:49:41');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `vatlieu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vatlieu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `TenVL` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Soluong_ton` int(11) NOT NULL,
  `last_change` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Don_gia` int(11) NOT NULL,
  `Donvi_tinh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_phieunhap` bigint(20) unsigned DEFAULT NULL,
  `id_phieuxuat` bigint(20) unsigned DEFAULT NULL,
  `id_ncc` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `vatlieu_id_phieunhap_foreign` (`id_phieunhap`),
  KEY `vatlieu_id_phieuxuat_foreign` (`id_phieuxuat`),
  KEY `vatlieu_id_ncc_foreign` (`id_ncc`),
  CONSTRAINT `vatlieu_id_ncc_foreign` FOREIGN KEY (`id_ncc`) REFERENCES `nhacungcaps` (`id`),
  CONSTRAINT `vatlieu_id_phieunhap_foreign` FOREIGN KEY (`id_phieunhap`) REFERENCES `phieunhap` (`id`),
  CONSTRAINT `vatlieu_id_phieuxuat_foreign` FOREIGN KEY (`id_phieuxuat`) REFERENCES `phieuxuat` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `vatlieu` WRITE;
/*!40000 ALTER TABLE `vatlieu` DISABLE KEYS */;
INSERT INTO `vatlieu` VALUES (9,'VL1',5,'0',50000,'Cái',NULL,NULL,2,'2020-11-28 13:17:43','2020-11-28 15:36:44'),(11,'VL2',6,NULL,50000,'Cái',NULL,NULL,3,'2020-11-28 15:48:55','2020-11-28 15:56:42'),(12,'VL3',0,NULL,50000,'Chọn...',NULL,NULL,3,'2020-11-29 02:31:07','2020-11-29 02:31:07');
/*!40000 ALTER TABLE `vatlieu` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `verifybackup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `verifybackup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `verify_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `verifybackup` WRITE;
/*!40000 ALTER TABLE `verifybackup` DISABLE KEYS */;
/*!40000 ALTER TABLE `verifybackup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

