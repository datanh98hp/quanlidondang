 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <h5>Danh sách backup file</h5>
        
        <ul class="list-group list-group-flush">
            <?php for($i = 0; $i < count($listfileBackUp); $i++): ?>
                <?php for($j = 0; $j < count($list_path); $j++): ?>
                    <li class="list-group-item">
                        <i href="<?php echo e($list_path[$j]); ?>"> <span><?php echo e($i); ?></span> - <?php echo e($listfileBackUp[$i]); ?> </i> 
                    <a class="btn btn-success justify-content-end" href="/download/backups-file-<?php echo e($listfileBackUp[$i]); ?>" download="<?php echo e($listfileBackUp[$i]); ?>"  target="_blank"> Tải về</a>
                    </li>    
                <?php endfor; ?>
                
            <?php endfor; ?>
          </ul>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/backup/backup.blade.php ENDPATH**/ ?>