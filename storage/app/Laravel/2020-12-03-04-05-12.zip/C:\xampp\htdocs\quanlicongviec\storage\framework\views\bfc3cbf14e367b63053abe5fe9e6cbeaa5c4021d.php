 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="row justify-content-center">
        <div class="col-md-8"> 
            <form class="form-group" action="/update-vl/<?php echo e($vl->id); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                <div class="form-group">
                  <label for="recipient-name" class="col-form-label">Tên Vật liệu:</label>
                  <input type="text" class="form-control" id="recipient-name" name="TenVL" value="<?php echo e($vl->TenVL); ?>">
                </div>
                <div class="form-group">
                  <label for="message-text" class="col-form-label" >Số lượng tồn:</label>
                  <input class="form-control" type="number" id="" name="Soluong_ton" value="<?php echo e($vl->Soluong_ton); ?>">
                </div>
                <div class="form-group">
                    <label for="recipient-name" class="col-form-label">Đơn giá:</label>
                    <input type="text" class="form-control" id="recipient-name" name="Don_gia" value="<?php echo e($vl->Don_gia); ?>">
                </div>
                <div class="form-group">
                    <label for="validationTooltip04">Đơn vị</label>
                        <select class="custom-select" id="validationTooltip04" name="Donvi_tinh" value="<?php echo e($vl->Donvi_tinh); ?>" required>
                            <option value="Cái" <?php if($vl->Donvi_tinh==="Cái"): ?>
                                selected="true"
                            <?php else: ?>
                            
                            <?php endif; ?>>Cái</option>
                            <option value="Cuộn" <?php if($vl->Donvi_tinh==="Cuộn"): ?>
                              selected="true"
                          <?php else: ?>
                         
                          <?php endif; ?>>Cuộn</option>
                          <option value="Tấm" <?php if($vl->Donvi_tinh==="Cuộn"): ?>
                            selected="true"
                        <?php else: ?>
                       
                        <?php endif; ?>>Tấm</option>
                        <option value="Mét vuông" <?php if($vl->Donvi_tinh==="Mét vuông"): ?>
                            selected="true"
                        <?php else: ?>
                       
                        <?php endif; ?>>Mét vuông</option>
                        <option value="Khác" <?php if($vl->Donvi_tinh==="Khác"): ?>
                            selected="true"
                        <?php else: ?>
                       
                        <?php endif; ?>>Khác</option>
                        </select>
                        <div class="invalid-tooltip">
                         Nhập đầy đủ thông tin
                        </div>
                </div>
                <div class="form-group">
                    <label for="recipient-name" class="col-form-label">Nhà cung cấp:</label>
                    <select class="custom-select" id="validationTooltip04" name="id_ncc" value="<?php echo e($vl->id_ncc); ?>">
                        <?php $__currentLoopData = $ncc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($nc->id===$vl->id_ncc): ?>
                                <option value="<?php echo e($nc->id); ?>" <?php if($vl->id_ncc===$nc->id): ?>
                                    selected="true"
                                <?php else: ?>
                            
                                <?php endif; ?>><?php echo e($nc->TenNCC); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($nc->id); ?>"><?php echo e($nc->TenNCC); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <button class="btn btn-success">Cập nhật</button>
                </div>
            </form>
        </div>
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
  <?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/danhmuc/vatlieu/Edit-vl.blade.php ENDPATH**/ ?>